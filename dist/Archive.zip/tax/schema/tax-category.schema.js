"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TaxCategorySchema = exports.TaxCategory = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const tax_exemption_schema_1 = require("./tax-exemption.schema");
let TaxCategory = class TaxCategory {
};
exports.TaxCategory = TaxCategory;
__decorate([
    (0, mongoose_1.Prop)({ required: true }),
    __metadata("design:type", String)
], TaxCategory.prototype, "name", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true }),
    __metadata("design:type", Number)
], TaxCategory.prototype, "ratePercent", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: [tax_exemption_schema_1.ExemptionSchema], default: [] }),
    __metadata("design:type", Array)
], TaxCategory.prototype, "exemptions", void 0);
exports.TaxCategory = TaxCategory = __decorate([
    (0, mongoose_1.Schema)()
], TaxCategory);
exports.TaxCategorySchema = mongoose_1.SchemaFactory.createForClass(TaxCategory);
//# sourceMappingURL=tax-category.schema.js.map